import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        BankSystem bank = new BankSystem();

        while (true) {

            String line = input.nextLine().trim();
            String[] cmd = line.split(" ");

            if (cmd[0].equals("exit")) {
                System.out.println("Goodbye!");
                break;
            }

            switch (cmd[0]) {

                case "register":
                    if (cmd.length < 6) {
                        System.out.println("Error: invalid arguments.");
                        break;
                    }
                    String user = cmd[1];
                    String pass = cmd[2];
                    String full = cmd[3] + " " + cmd[4];
                    String phone = cmd[5];
                    String email = cmd[6];
                    String a=bank.register(user, pass, full, phone, email);
                    System.out.print(a);
                    break;

                case "login":
                    if(cmd.length<3)
                    {
                        System.out.println("Error: invalid arguments.");
                        break;
                    }
                    System.out.println(bank.login(cmd[1], cmd[2]));
                    break;

                case "logout":
                    System.out.println(bank.logout());
                    break;

                case "show":
                    if(cmd.length<2 || !cmd[1].equals("balance")) {
                        System.out.println("Error: invalid arguments.");
                        break;
                    }
                    if (cmd[1].equals("balance")){
                        bank.showBalance();

                    break;}




                case "deposit":
                    if(cmd.length<2)
                    {
                        System.out.println("Error: invalid arguments.");
                        break;
                    }
                    bank.deposit(Double.parseDouble(cmd[1]));
                    break;

                case "withdraw":
                    if(cmd.length<2)
                    {
                        System.out.println("Error: invalid arguments.");
                    }
                    bank.withdraw(Double.parseDouble(cmd[1]));
                    break;

                case "transfer":
                    if(cmd.length<3)
                    {
                        System.out.println("Error: invalid arguments.");
                        break;
                    }
                            bank.transfer(cmd[1], Double.parseDouble(cmd[2]));
                    break;

                default:
                    System.out.println("Error: unknown command.");
            }
        }
    }
}
