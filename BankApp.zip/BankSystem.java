import java.util.*;

public class BankSystem {
    private ArrayList<BankApp> users = new ArrayList<>();
    private BankApp loggedInUser = null;
    private BankApp giverUser = null;

    public String register(String username, String password, String fullName, String phoneNumber, String email) {
        for (BankApp user : users) {
            if (user.getUsername().equals(username)) {
                return "this username has already been taken.";
            }
        }
        if (!isValidPassword(password)) {
            return "invalid password.";
        }
        if (!isValidPhoneNumber(phoneNumber)) {
            return "invalid phoneNumber.";
        }
        if (!isValidEmail(email)) {
            return "invalid email.";
        }
        String cardNumber = randomCardNumber();
        BankApp newUser = new BankApp(username, password, fullName, cardNumber, phoneNumber, email);
        users.add(newUser);
        System.out.print("Assigned card number: " +newUser.getCardNumber()+"\n" );
        return "Registered successfully.";

    }

    public String login(String Username, String Password) {
        for (BankApp user : users) {
            if (user.getUsername().equals(Username) && user.getPasword().equals(Password)) {
                loggedInUser = user;
                return "Login successful.";

            }
        }
        return "invalid username or password.";
    }

    public void showBalance() {
        if (loggedInUser == null) {
            System.out.print("please login first.");
        } else {
            System.out.print(loggedInUser.getBalance());
        }

    }

    public void deposit(double amount) {
        if (loggedInUser == null) {
            System.out.print("please log in first.");
        } else {
            loggedInUser.setBalance(loggedInUser.getBalance() + amount);
            System.out.print(loggedInUser.getUsername() + "'s" + "blance is: " + loggedInUser.getBalance());
        }
    }

    public void withdraw(double amount) {
        if (loggedInUser == null) {
            System.out.print("please log in first.");
        } else if (loggedInUser.getBalance() < amount) {
            System.out.print("Insufficient account balance");
        } else {
            loggedInUser.setBalance(loggedInUser.getBalance() - amount);
            System.out.print(loggedInUser.getUsername() + "'s" + "blance is: " + loggedInUser.getBalance());
        }

    }

    public void transfer(String CardNumber, double amount) {
        int flag = 0;
        for (BankApp user : users) {
            if (user.getCardNumber().equals(CardNumber)) {
                flag = 1;
                giverUser = user;
                break;

            }
        }
        if (loggedInUser == null) {
            System.out.print("please log in first.");
            return;
        } else if (loggedInUser.getBalance() < amount) {
            System.out.print("Insufficient account balance");
            return;
        } else if (flag == 0) {
            System.out.print("Wrong CardNumber!");
            return;
        } else {
            withdraw(amount);
            giverUser.setBalance(giverUser.getBalance() + amount);
        }

    }
    public String logout()
    {
        if (loggedInUser == null) {
            return "Please login first.";
        }
        else
        {
            loggedInUser=null;
            return "Logout successful.";
        }

    }
    public void exit()
    {

    }
    private boolean isValidPassword(String password) {
        if (password.length() < 8) {
            return false;
        }
        boolean hasUpper = false;
        boolean hasLower = false;
        boolean hasDigit = false;
        boolean hasSpecial = false;
        String specials = "@!&$؟";
        for (int i = 0; i < password.length(); i++) {
            char c = password.charAt(i);
            if (Character.isUpperCase(c)) {
                hasUpper = true;
            } else if (Character.isLowerCase(c)) {
                hasLower = true;
            } else if (Character.isDigit(c)) {
                hasDigit = true;
            } else if (specials.indexOf(c) != -1) {
                hasSpecial = true;
            }
        }
        return hasUpper && hasLower && hasDigit && hasSpecial;

    }

    private boolean isValidPhoneNumber(String phoneNumber) {
        if (phoneNumber.length() != 11) {
            return false;
        }
        if (!phoneNumber.startsWith("09")) {
            return false;
        }
        for (int i = 2; i < phoneNumber.length(); i++) {
            char c = phoneNumber.charAt(i);
            if (!Character.isDigit(c)) {
                return false;
            }
        }
        return true;
    }

    private boolean isValidEmail(String email) {
        int index = email.indexOf("@");
        if (index <= 0) {
            return false;
        }
        if (email.charAt(0) == '.') {
            return false;
        }
        String after = email.substring(index + 1);
        if (!after.equals("aut.com")) {
            return false;
        }
        return true;
    }

    private String randomCardNumber() {
        String base = "6037";
        String num = "";

        while (true) {
            num = base;
            for (int i = 0; i < 12; i++) {
                int digit = (int) (Math.random() * 10);
                num += digit;
            }

            boolean exists = false;
            for (BankApp user : users) {
                if (user.getCardNumber().equals(num)) {
                    exists = true;
                    break;
                }
            }

            if (!exists) return num;
        }
    }

}
