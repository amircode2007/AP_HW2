public class BankApp {
    private String username;
    private String pasword;
    private String fullName;
    private String cardNumber;
    private String phoneNumber;
    private String email;
    private double balance;

    public BankApp(String username, String pasword, String fullName, String cardNumber, String phoneNumber, String email)
    {
        this.username=username;
        this.pasword=pasword;
        this.fullName=fullName;
        this.cardNumber=cardNumber;
        this.phoneNumber=phoneNumber;
        this.email=email;
        this.balance=0.0;
    }
    public String getUsername()
    {
        return this.username;
    }
    public String getPasword()
    {
        return this.pasword;
    }
    public String getFullName() {

    return this.fullName;

    }
    public String getCardNumber()
    {
        return this.cardNumber;
    }
    public String getPhoneNumber()
    {
        return this.phoneNumber;
    }
    public double getBalance()
    {
        return this.balance;
    }
    public void setBalance( double balance)
    {
        this.balance =balance;
    }
}